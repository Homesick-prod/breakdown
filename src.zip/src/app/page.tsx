'use client';

import React, { useState, useCallback, useEffect } from 'react';
import ProjectDashboard from '../components/ProjectDashboard';
import ShootingScheduleEditor from '../components/ShootingScheduleEditor';
import ShotListEditor from '../components/ShotListEditor';

function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedProject, setSelectedProject] = useState(null);

  const handleSelectProject = useCallback((project, mode = 'schedule') => {
    setSelectedProject(project);
    setCurrentView(mode === 'schedule' ? 'scheduleEditor' : 'shotListEditor');
  }, []);

  const handleCreateProject = useCallback((project) => {
    setSelectedProject(project);
    // Default to opening the schedule editor for new projects
    setCurrentView('scheduleEditor');
  }, []);

  const handleSaveProject = useCallback((data, mode) => {
    if (!selectedProject) return;

    const projects = JSON.parse(localStorage.getItem('shootingScheduleProjects') || '[]');
    const updatedProjects = projects.map(p => {
      if (p.id === selectedProject.id) {
        const updatedProject = { ...p, updatedAt: new Date().toISOString() };
        
        // Ensure the data object exists
        if (!updatedProject.data) {
            updatedProject.data = {};
        }

        if (mode === 'schedule') {
          updatedProject.data.schedule = data;
          // Also update the project name from the schedule's header info
          if (data.headerInfo && data.headerInfo.projectTitle) {
            updatedProject.name = data.headerInfo.projectTitle;
          }
        } else if (mode === 'shotList') {
          updatedProject.data.shotList = data;
        }
        return updatedProject;
      }
      return p;
    });

    localStorage.setItem('shootingScheduleProjects', JSON.stringify(updatedProjects));
  }, [selectedProject]);

  const handleBackToDashboard = useCallback(() => {
    setCurrentView('dashboard');
    setSelectedProject(null);
  }, []);

  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    document.body.style.fontFamily = "'Plus Jakarta Sans', 'IBM Plex Sans Thai', sans-serif";
  }, []);

  const renderView = () => {
    switch (currentView) {
      case 'scheduleEditor':
        return (
          <ShootingScheduleEditor
            project={selectedProject}
            onBack={handleBackToDashboard}
            onSave={(data) => handleSaveProject(data, 'schedule')}
          />
        );
      case 'shotListEditor':
        return (
          <ShotListEditor
            project={selectedProject}
            onBack={handleBackToDashboard}
            onSave={(data) => handleSaveProject(data, 'shotList')}
          />
        );
      case 'dashboard':
      default:
        return (
          <ProjectDashboard
            onSelectProject={handleSelectProject}
            onCreateProject={handleCreateProject}
          />
        );
    }
  };

  return <>{renderView()}</>;
}

export default App;