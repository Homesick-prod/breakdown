'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Film, Upload, Plus, Folder, MoreVertical, Edit2, 
  Copy, FileDown, Trash2, Calendar, Clock, AlertCircle 
} from 'lucide-react';
import { generateId } from '../utils/id';
import { exportProject, importProject } from '../utils/file';
import Footer from './Footer';

// Type definitions
interface Project {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
  data?: any;
}

interface ProjectDashboardProps {
  onSelectProject: (project: Project) => void;
  onCreateProject: (project: Project) => void;
}

// Empty state component
const EmptyState: React.FC<{ onCreateProject: () => void }> = ({ onCreateProject }) => (
  <div className="text-center py-24">
    <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gray-100 mb-6">
      <Folder className="w-10 h-10 text-gray-400" />
    </div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">No projects yet</h3>
    <p className="text-gray-500 mb-8 max-w-sm mx-auto">
      Create your first shooting schedule project and start organizing your film production.
    </p>
    <button
      onClick={onCreateProject}
      className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm hover:shadow-md"
    >
      <Plus className="w-5 h-5" />
      Create Your First Project
    </button>
  </div>
);

// Project card menu component
const ProjectCardMenu: React.FC<{
  project: Project;
  onEdit: () => void;
  onDuplicate: () => void;
  onExport: () => void;
  onDelete: () => void;
}> = ({ project, onEdit, onDuplicate, onExport, onDelete }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={menuRef} className="relative">
      <button
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(!isOpen);
        }}
        className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
        aria-label="Project options"
      >
        <MoreVertical className="w-4 h-4 text-gray-500" />
      </button>

      {isOpen && (
        <div className="absolute right-0 top-10 w-48 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-10">
          <button 
            onClick={(e) => { 
              e.stopPropagation(); 
              onEdit(); 
              setIsOpen(false); 
            }} 
            className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2 transition-colors"
          >
            <Edit2 className="w-4 h-4" /> 
            Edit Details
          </button>
          <button 
            onClick={(e) => { 
              e.stopPropagation(); 
              onDuplicate(); 
              setIsOpen(false); 
            }} 
            className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2 transition-colors"
          >
            <Copy className="w-4 h-4" /> 
            Duplicate
          </button>
          <button 
            onClick={(e) => { 
              e.stopPropagation(); 
              onExport(); 
              setIsOpen(false); 
            }} 
            className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2 transition-colors"
          >
            <FileDown className="w-4 h-4" /> 
            Export
          </button>
          <div className="border-t border-gray-100 my-1"></div>
          <button 
            onClick={(e) => { 
              e.stopPropagation(); 
              onDelete(); 
              setIsOpen(false); 
            }} 
            className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2 transition-colors"
          >
            <Trash2 className="w-4 h-4" /> 
            Delete
          </button>
        </div>
      )}
    </div>
  );
};

// Modal component for creating/editing projects
const ProjectModal: React.FC<{
  isOpen: boolean;
  mode: 'create' | 'edit';
  name: string;
  description: string;
  onNameChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onClose: () => void;
  onSubmit: () => void;
}> = ({ isOpen, mode, name, description, onNameChange, onDescriptionChange, onClose, onSubmit }) => {
  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4">
        <div 
          className="fixed inset-0 bg-black bg-opacity-25 transition-opacity" 
          onClick={onClose}
        />
        <div className="relative bg-white rounded-xl shadow-xl max-w-md w-full p-6 transform transition-all">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            {mode === 'create' ? 'Create New Project' : 'Edit Project'}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Project Name
              </label>
              <input 
                type="text" 
                value={name} 
                onChange={(e) => onNameChange(e.target.value)} 
                placeholder="Enter project name" 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all" 
                autoFocus 
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description (Optional)
              </label>
              <textarea 
                value={description} 
                onChange={(e) => onDescriptionChange(e.target.value)} 
                placeholder="Brief description of your project" 
                rows={3} 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none transition-all" 
              />
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button 
                type="button"
                onClick={onClose} 
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button 
                type="submit"
                disabled={!name.trim()} 
                className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {mode === 'create' ? 'Create Project' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

// Main dashboard component
const ProjectDashboard: React.FC<ProjectDashboardProps> = ({ onSelectProject, onCreateProject }) => {
  // State management
  const [projects, setProjects] = useState<Project[]>([]);
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDescription, setNewProjectDescription] = useState('');
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editedName, setEditedName] = useState('');
  const [editedDescription, setEditedDescription] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load projects from localStorage on mount
  useEffect(() => {
    try {
      const savedProjects = localStorage.getItem('shootingScheduleProjects');
      if (savedProjects) {
        const parsedProjects: Project[] = JSON.parse(savedProjects);
        // Sort by most recently updated
        parsedProjects.sort((a, b) => 
          new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        );
        setProjects(parsedProjects);
      }
    } catch (error) {
      console.error('Error loading projects:', error);
      setError('Failed to load projects. Please refresh the page.');
    }
  }, []);

  // Project CRUD operations
  const handleCreateProject = useCallback(() => {
    if (!newProjectName.trim()) return;

    const newProject: Project = {
      id: generateId(),
      name: newProjectName.trim(),
      description: newProjectDescription.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      data: null
    };

    const updatedProjects = [newProject, ...projects];
    setProjects(updatedProjects);
    localStorage.setItem('shootingScheduleProjects', JSON.stringify(updatedProjects));
    
    // Reset form and close modal
    setNewProjectName('');
    setNewProjectDescription('');
    setShowNewProjectModal(false);
    
    // Navigate to the new project
    onCreateProject(newProject);
  }, [newProjectName, newProjectDescription, projects, onCreateProject]);

  const handleUpdateProject = useCallback(() => {
    if (!editingProject || !editedName.trim()) return;

    const updatedProjects = projects.map(p =>
      p.id === editingProject.id 
        ? { 
            ...p, 
            name: editedName.trim(), 
            description: editedDescription.trim(), 
            updatedAt: new Date().toISOString() 
          } 
        : p
    );

    // Re-sort by updated date
    updatedProjects.sort((a, b) => 
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );

    setProjects(updatedProjects);
    localStorage.setItem('shootingScheduleProjects', JSON.stringify(updatedProjects));
    setEditingProject(null);
  }, [editingProject, editedName, editedDescription, projects]);

  const handleDeleteProject = useCallback((projectId: string) => {
    const projectToDelete = projects.find(p => p.id === projectId);
    if (!projectToDelete) return;

    const confirmMessage = `Are you sure you want to delete "${projectToDelete.name}"? This action cannot be undone.`;
    
    if (window.confirm(confirmMessage)) {
      const updatedProjects = projects.filter(p => p.id !== projectId);
      setProjects(updatedProjects);
      localStorage.setItem('shootingScheduleProjects', JSON.stringify(updatedProjects));
    }
  }, [projects]);

  const handleDuplicateProject = useCallback((project: Project) => {
    const duplicatedProject: Project = {
      ...project,
      id: generateId(),
      name: `${project.name} (Copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updatedProjects = [duplicatedProject, ...projects];
    setProjects(updatedProjects);
    localStorage.setItem('shootingScheduleProjects', JSON.stringify(updatedProjects));
  }, [projects]);

  const handleExportProject = useCallback((project: Project) => {
    try {
      exportProject(project);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Failed to export project. Please try again.');
    }
  }, []);

  const handleImportProject = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const importedProject = await importProject(file);
      const updatedProjects = [...projects, importedProject];
      
      // Sort by updated date
      updatedProjects.sort((a, b) => 
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      );
      
      setProjects(updatedProjects);
      localStorage.setItem('shootingScheduleProjects', JSON.stringify(updatedProjects));
      
      alert('Project imported successfully!');
    } catch (error: any) {
      alert(error.message || 'Failed to import project. Please check the file and try again.');
    }

    // Reset file input
    if (e.target) e.target.value = '';
  }, [projects]);

  // Edit modal handlers
  const handleOpenEditModal = useCallback((project: Project) => {
    setEditingProject(project);
    setEditedName(project.name);
    setEditedDescription(project.description || '');
  }, []);

  const handleCloseEditModal = useCallback(() => {
    setEditingProject(null);
    setEditedName('');
    setEditedDescription('');
  }, []);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Navigation Header */}
      <nav className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <Film className="w-8 h-8 text-indigo-600" />
              <div>
                <h1 className="text-xl font-semibold text-gray-900">MentalBreakdown</h1>
                <p className="text-xs text-gray-500">Film Shooting Schedule Editor</p>
              </div>
            </div>
            <button 
              onClick={() => fileInputRef.current?.click()} 
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors"
            >
              <Upload className="w-4 h-4" />
              Import Project
            </button>
            <input 
              ref={fileInputRef} 
              type="file" 
              accept=".mbd,.json" 
              onChange={handleImportProject} 
              className="hidden" 
            />
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">Your Projects</h2>
            <p className="text-gray-600">Manage your shooting schedules and production timelines</p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              <span>{error}</span>
            </div>
          )}

          {/* Projects Grid */}
          {projects.length === 0 ? (
            <EmptyState onCreateProject={() => setShowNewProjectModal(true)} />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {/* Create New Project Card */}
              <button 
                onClick={() => setShowNewProjectModal(true)} 
                className="h-64 rounded-xl border-2 border-dashed border-gray-300 hover:border-indigo-400 hover:bg-gray-50 transition-all duration-200 group"
              >
                <div className="flex flex-col items-center justify-center h-full">
                  <div className="w-12 h-12 rounded-full bg-gray-100 group-hover:bg-indigo-100 flex items-center justify-center mb-3 transition-colors">
                    <Plus className="w-6 h-6 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                  </div>
                  <span className="text-gray-600 font-medium group-hover:text-indigo-600 transition-colors">
                    Create New Project
                  </span>
                </div>
              </button>

              {/* Project Cards */}
              {projects.map(project => (
                <div 
                  key={project.id} 
                  onClick={() => onSelectProject(project)}
                  className="h-64 bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md hover:border-gray-200 transition-all duration-200 cursor-pointer group overflow-hidden flex flex-col"
                >
                  <div className="flex-1 p-6">
                    <div className="flex items-start justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                        {project.name}
                      </h3>
                      <ProjectCardMenu
                        project={project}
                        onEdit={() => handleOpenEditModal(project)}
                        onDuplicate={() => handleDuplicateProject(project)}
                        onExport={() => handleExportProject(project)}
                        onDelete={() => handleDeleteProject(project.id)}
                      />
                    </div>
                    <p className="text-sm text-gray-600 line-clamp-3 mb-4">
                      {project.description || 'No description'}
                    </p>
                  </div>
                  <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDate(project.updatedAt)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatTime(project.updatedAt)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />

      {/* Create Project Modal */}
      <ProjectModal
        isOpen={showNewProjectModal}
        mode="create"
        name={newProjectName}
        description={newProjectDescription}
        onNameChange={setNewProjectName}
        onDescriptionChange={setNewProjectDescription}
        onClose={() => setShowNewProjectModal(false)}
        onSubmit={handleCreateProject}
      />

      {/* Edit Project Modal */}
      <ProjectModal
        isOpen={!!editingProject}
        mode="edit"
        name={editedName}
        description={editedDescription}
        onNameChange={setEditedName}
        onDescriptionChange={setEditedDescription}
        onClose={handleCloseEditModal}
        onSubmit={handleUpdateProject}
      />
    </div>
  );
};

export default ProjectDashboard;